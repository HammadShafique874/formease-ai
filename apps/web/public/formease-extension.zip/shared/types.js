export function isExtensionMessage(v) {
    if (typeof v !== "object" || v === null)
        return false;
    const t = v.type;
    return t === "SCAN_FORM" || t === "HIGHLIGHT_FIELD" || t === "OPEN_DASHBOARD" || t === "STORE_SCAN_AND_OPEN";
}
